

library(testthat)
library(dsem)

# Run tests
testthat::test_check("dsem")

# Run from local directory
# testthat::test_dir( "C:/Users/James.Thorson/Desktop/Git/dsem/tests/testthat/", reporter="check" )
